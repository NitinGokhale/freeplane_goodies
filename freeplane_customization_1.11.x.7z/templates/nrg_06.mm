<map version="freeplane 1.9.8">
<!--To view this file, download free mind mapping software Freeplane from https://www.freeplane.org -->
<node TEXT="new mindmap" LOCALIZED_STYLE_REF="AutomaticLayout.level.root" FOLDED="false" ID="ID_1462853497" CREATED="1618421711776" MODIFIED="1618439224860"><hook NAME="MapStyle" zoom="0.9">
    <properties show_icon_for_attributes="true" fit_to_viewport="false" show_note_icons="true" edgeColorConfiguration="#D4D4D4,#93E97D,#D1DC7D,#F2D091,#F2CCC0,#F1CBD1,#F1C9DF,#D6D1F0,#D4D4D4,#C1D6F0,#99DFF1,#84E5DA,#81E8BC" associatedTemplateLocation="template:/nrg.mm"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" STYLE="oval" UNIFORM_SHAPE="true" VGAP_QUANTITY="24 pt" TEXT_SHORTENED="true">
<font SIZE="24" BOLD="true"/>
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="right" STYLE="bubble">
<font SIZE="9"/>
<stylenode LOCALIZED_TEXT="default" ID="ID_92100152" COLOR="#202020" STYLE="bubble" TEXT_ALIGN="LEFT" BORDER_WIDTH="2 px">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" DASH="" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_92100152" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<font NAME="Calibri" SIZE="8" BOLD="false" ITALIC="false"/>
<edge STYLE="bezier" WIDTH="2"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details">
<font SIZE="11"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.attributes" BACKGROUND_COLOR="#cccccc" VGAP_QUANTITY="5 pt">
<font SIZE="9"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.note" COLOR="#767eea" BACKGROUND_COLOR="#ffffff"/>
<stylenode LOCALIZED_TEXT="defaultstyle.floating">
<edge STYLE="hide_edge"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.selection" BACKGROUND_COLOR="#d8d8d8" BORDER_COLOR_LIKE_EDGE="false" BORDER_COLOR="#000000"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="right" STYLE="bubble">
<font SIZE="9"/>
<stylenode LOCALIZED_TEXT="styles.important">
<icon BUILTIN="yes"/>
<edge COLOR="#0000cc"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="right" STYLE="bubble">
<font SIZE="9"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" BACKGROUND_COLOR="#cccccc" STYLE="bubble" VGAP_QUANTITY="20 pt" BORDER_WIDTH="4 pt" MAX_WIDTH="120 pt" MIN_WIDTH="120 pt">
<font SIZE="18" BOLD="true"/>
<edge WIDTH="8"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1" VGAP_QUANTITY="16 pt" BORDER_WIDTH="4 px" MAX_WIDTH="160 pt" MIN_WIDTH="160 pt">
<font SIZE="16" BOLD="false"/>
<edge WIDTH="6"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2" VGAP_QUANTITY="12 pt" BORDER_WIDTH="3.2 px" MAX_WIDTH="160 pt" MIN_WIDTH="160 pt">
<font SIZE="14" BOLD="false"/>
<edge WIDTH="4"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3" VGAP_QUANTITY="8 pt" BORDER_WIDTH="2.4 px" MAX_WIDTH="160 pt" MIN_WIDTH="160 pt">
<font SIZE="12" BOLD="false"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4" VGAP_QUANTITY="4 pt" BORDER_WIDTH="2.4 px" MAX_WIDTH="180 pt" MIN_WIDTH="180 pt">
<font SIZE="12" BOLD="false"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,5">
<font SIZE="11" BOLD="false"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,6">
<font SIZE="10" BOLD="false"/>
</stylenode>
</stylenode>
</stylenode>
</map_styles>
</hook>
<hook NAME="AutomaticEdgeColor" COUNTER="19" RULE="ON_BRANCH_CREATION"/>
<edge COLOR="#cccccc"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties" VALUE="ALL"/>
<node TEXT="Colors" POSITION="left" ID="ID_1538472842" CREATED="1618439659394" MODIFIED="1618439732850" BACKGROUND_COLOR="#e6e6e6">
<edge COLOR="#e6e6e6"/>
<node TEXT="" ID="ID_1650589921" CREATED="1656111633067" MODIFIED="1656120429593" BACKGROUND_COLOR="#d4d4d4">
<edge COLOR="#d4d4d4"/>
<node TEXT="" ID="ID_1809721026" CREATED="1618435733939" MODIFIED="1656120370095" BACKGROUND_COLOR="#eeeeee">
<node TEXT="border" ID="ID_953243603" CREATED="1656111702537" MODIFIED="1657290427682" COLOR="#ffffff" BACKGROUND_COLOR="#747474">
<edge COLOR="#747474"/>
</node>
</node>
</node>
<node TEXT="" ID="ID_1018419644" CREATED="1656111633067" MODIFIED="1656120448299" BACKGROUND_COLOR="#c1d6f0">
<edge COLOR="#c1d6f0"/>
<node TEXT="" ID="ID_25326238" CREATED="1618435733939" MODIFIED="1656120381606" BACKGROUND_COLOR="#e6eff9">
<node TEXT="border" ID="ID_1713876706" CREATED="1656111702537" MODIFIED="1657290430302" COLOR="#ffffff" BACKGROUND_COLOR="#4c78a4">
<edge COLOR="#4c78a4"/>
</node>
</node>
</node>
<node TEXT="" ID="ID_458979286" CREATED="1656111633067" MODIFIED="1656120465855" BACKGROUND_COLOR="#99dff1">
<edge COLOR="#99dff1"/>
<node TEXT="" ID="ID_977733054" CREATED="1618435733939" MODIFIED="1656120387755" BACKGROUND_COLOR="#daf2f9">
<node TEXT="border" ID="ID_1638270631" CREATED="1656111702537" MODIFIED="1657290432807" COLOR="#ffffff" BACKGROUND_COLOR="#487c89">
<edge COLOR="#487c89"/>
</node>
</node>
</node>
<node TEXT="" ID="ID_849212294" CREATED="1656111633067" MODIFIED="1656120471505" BACKGROUND_COLOR="#84e5da">
<edge COLOR="#84e5da"/>
<node TEXT="" ID="ID_1388973374" CREATED="1618435733939" MODIFIED="1656120388699" BACKGROUND_COLOR="#bff9f2">
<node TEXT="border" ID="ID_1860174524" CREATED="1656111702537" MODIFIED="1657290467990" COLOR="#ffffff" BACKGROUND_COLOR="#467e7a">
<edge COLOR="#467e7a"/>
</node>
</node>
</node>
<node TEXT="" ID="ID_836252951" CREATED="1656111633067" MODIFIED="1656120500301" BACKGROUND_COLOR="#81e8bc">
<edge COLOR="#81e8bc"/>
<node TEXT="" ID="ID_732867311" CREATED="1618435733939" MODIFIED="1656120389377" BACKGROUND_COLOR="#c6f9e0">
<node TEXT="border" ID="ID_1278923834" CREATED="1656111702537" MODIFIED="1657290467989" COLOR="#ffffff" BACKGROUND_COLOR="#458068">
<edge COLOR="#458068"/>
</node>
</node>
</node>
<node TEXT="" ID="ID_234986760" CREATED="1656111633067" MODIFIED="1656120517088" BACKGROUND_COLOR="#93e97d">
<edge COLOR="#93e97d"/>
<node TEXT="" ID="ID_779140453" CREATED="1618435733939" MODIFIED="1656120390004" BACKGROUND_COLOR="#cef9c5">
<node TEXT="border" ID="ID_1011210269" CREATED="1656111702537" MODIFIED="1657290467988" COLOR="#ffffff" BACKGROUND_COLOR="#4a8142">
<edge COLOR="#4a8142"/>
</node>
</node>
</node>
<node TEXT="" ID="ID_1539322207" CREATED="1656111633067" MODIFIED="1656120523050" BACKGROUND_COLOR="#d1dc7d">
<edge COLOR="#d1dc7d"/>
<node TEXT="" ID="ID_1655779658" CREATED="1618435733939" MODIFIED="1656120390676" BACKGROUND_COLOR="#ebf68d">
<node TEXT="border" ID="ID_746959519" CREATED="1656111702537" MODIFIED="1657290467987" COLOR="#ffffff" BACKGROUND_COLOR="#717942">
<edge COLOR="#717942"/>
</node>
</node>
</node>
<node TEXT="" ID="ID_390713702" CREATED="1656111633067" MODIFIED="1656120543131" BACKGROUND_COLOR="#f2d091">
<edge COLOR="#f2d091"/>
<node TEXT="" ID="ID_1537873249" CREATED="1618435733939" MODIFIED="1656120391312" BACKGROUND_COLOR="#f9ecd8">
<node TEXT="border" ID="ID_1831152113" CREATED="1656111702537" MODIFIED="1657290467986" COLOR="#ffffff" BACKGROUND_COLOR="#877243">
<edge COLOR="#877243"/>
</node>
</node>
</node>
<node TEXT="" ID="ID_183150198" CREATED="1656111633067" MODIFIED="1656120548220" BACKGROUND_COLOR="#f2ccc0">
<edge COLOR="#f2ccc0"/>
<node TEXT="" ID="ID_1607410075" CREATED="1618435733939" MODIFIED="1656120391999" BACKGROUND_COLOR="#f9ebe6">
<node TEXT="border" ID="ID_1089952428" CREATED="1656111702537" MODIFIED="1657290467985" COLOR="#ffffff" BACKGROUND_COLOR="#a06743">
<edge COLOR="#a06743"/>
</node>
</node>
</node>
<node TEXT="" ID="ID_1821114247" CREATED="1656111633067" MODIFIED="1656120564896" BACKGROUND_COLOR="#f1cbd1">
<edge COLOR="#f1cbd1"/>
<node TEXT="" ID="ID_634916378" CREATED="1618435733939" MODIFIED="1656120392666" BACKGROUND_COLOR="#f9eaec">
<node TEXT="border" ID="ID_1633907544" CREATED="1656111702537" MODIFIED="1657290467984" COLOR="#ffffff" BACKGROUND_COLOR="#c9455e">
<edge COLOR="#c9455e"/>
</node>
</node>
</node>
<node TEXT="" ID="ID_89430697" CREATED="1656111633067" MODIFIED="1656120570048" BACKGROUND_COLOR="#f1c9df">
<edge COLOR="#f1c9df"/>
<node TEXT="" ID="ID_1770049842" CREATED="1618435733939" MODIFIED="1656120394063" BACKGROUND_COLOR="#f9eaf2">
<node TEXT="border" ID="ID_605857884" CREATED="1656111702537" MODIFIED="1657290467982" COLOR="#ffffff" BACKGROUND_COLOR="#bc4a90">
<edge COLOR="#bc4a90"/>
</node>
</node>
</node>
<node TEXT="" ID="ID_509110654" CREATED="1656111633067" MODIFIED="1656120585994" BACKGROUND_COLOR="#d6d1f0">
<edge COLOR="#d6d1f0"/>
<node TEXT="" ID="ID_384094632" CREATED="1618435733939" MODIFIED="1656120394974" BACKGROUND_COLOR="#eeedf9">
<node TEXT="border" ID="ID_284944588" CREATED="1656111702537" MODIFIED="1657290467978" COLOR="#ffffff" BACKGROUND_COLOR="#8062cc">
<edge COLOR="#8062cc"/>
</node>
</node>
</node>
</node>
</node>
</map>
