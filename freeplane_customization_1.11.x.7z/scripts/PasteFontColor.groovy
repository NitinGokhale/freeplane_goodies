import java.awt.Toolkit
import java.awt.datatransfer.Clipboard
import java.awt.datatransfer.DataFlavor

// define static functions to get and set clipboard text
static String getClipboardContents(){return Toolkit.getDefaultToolkit().getSystemClipboard().getContents(null).getTransferData(DataFlavor.stringFlavor)}

// @ExecutionModes({ON_SELECTED_NODE})
node.style.textColorCode = getClipboardContents().toLowerCase();

// print "${node.id}\n";
