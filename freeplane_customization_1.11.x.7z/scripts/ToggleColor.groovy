// @ExecutionModes({ON_SELECTED_NODE})

String bc = node.style.backgroundColorCode;
String ec = node.style.getEdge().getColorCode();
String fc = node.style.textColorCode;

// logger.info("## map bc: ${node.getMindMap().getBackgroundColorCode()}");


if (!node.style.isBackgroundColorSet()) {
  bc = "#ffffff";
}

if (bc == "#ffffff") {
  // bc is white
  newbc = ec;
  newec = ec;

  if (fc == "#000000") {
    newfc = "#ffffff";
  } else {
    newfc = "#000000";
  }

} else {
  // bc not white
  newbc = ec;
  newec = bc;
  if (bc != ec) {
    // swap background and edge colors
    newfc = newec;
  } else {
    // bc equals ec
    if ((fc != ec) && (bc != "#000000") && (bc != "#ffffff")) {
      // change font color to black (or white)
      if (fc == "#000000") {
        newfc = "#ffffff";
      } else {
        newfc = "#000000";
      }
    } else {
      // change background to white
      newbc = "#ffffff";
      newec = ec;
      newfc = ec;
    }
  }
}

node.style.setBackgroundColorCode(newbc);
node.style.getEdge().setColorCode(newec);
node.style.textColorCode = newfc;

