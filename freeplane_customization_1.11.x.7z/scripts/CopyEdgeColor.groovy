// @ExecutionModes({ON_SELECTED_NODE})
textUtils.copyToClipboard(node.style.getEdge().getColorCode());
