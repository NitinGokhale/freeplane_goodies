// @ExecutionModes({ON_SELECTED_NODE})

String bc = node.style.backgroundColorCode;
String fc = node.style.textColorCode;

// logger.info("## map bc: ${node.getMindMap().getBackgroundColorCode()}");


if (!node.style.isBackgroundColorSet()) {
  bc = "#ffffff";
}

node.style.setBackgroundColorCode(fc);
node.style.textColorCode = bc;

