// @ExecutionModes({ON_SELECTED_NODE})

String bc = node.style.backgroundColorCode;
String ec = node.style.getEdge().getColorCode();

// logger.info("## map bc: ${node.getMindMap().getBackgroundColorCode()}");


if (!node.style.isBackgroundColorSet()) {
  bc = "#ffffff";
}

node.style.setBackgroundColorCode(ec);
node.style.getEdge().setColorCode(bc);

