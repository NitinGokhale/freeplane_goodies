// @ExecutionModes({ON_SELECTED_NODE})

String ec = node.style.getEdge().getColorCode();

if (ec != "#ffffff") {
  node.style.setBackgroundColorCode(ec);
}

node.style.textColorCode = "#000000";
