// @ExecutionModes({ON_SELECTED_NODE})

String ec = node.style.getEdge().getColorCode();
String bc = node.style.backgroundColorCode;

if (!node.style.isBackgroundColorSet()) {
  bc = "#ffffff";
}

if (bc != "#ffffff") {
  if (ec != bc) {
    node.style.getEdge().setColorCode(bc);
  }
}

node.style.textColorCode = "#000000";
