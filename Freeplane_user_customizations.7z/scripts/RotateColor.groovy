// @ExecutionModes({ON_SELECTED_NODE})

String ec = node.style.getEdge().getColorCode();
String bc = node.style.backgroundColorCode;
String fc = node.style.textColorCode;

// logger.info("## map bc: ${node.getMindMap().getBackgroundColorCode()}");


if (!node.style.isBackgroundColorSet()) {
  bc = "#ffffff";
}

if (bc == ec) {
  if (bc != fc) {
    node.style.setBackgroundColorCode(fc);
    node.style.getEdge().setColorCode(fc);
    node.style.textColorCode = bc;
  }
} else {
  if (ec == fc) {
    node.style.setBackgroundColorCode(fc);
    node.style.getEdge().setColorCode(bc);
    node.style.textColorCode = bc;
  } else {
    node.style.setBackgroundColorCode(fc);
    node.style.getEdge().setColorCode(bc);
    node.style.textColorCode = ec;
  }
}
