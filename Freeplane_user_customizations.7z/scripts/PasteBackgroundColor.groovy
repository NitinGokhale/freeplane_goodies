import java.awt.Toolkit
import java.awt.datatransfer.Clipboard
import java.awt.datatransfer.DataFlavor

// define static functions to get and set clipboard text
static String getClipboardContents(){return Toolkit.getDefaultToolkit().getSystemClipboard().getContents(null).getTransferData(DataFlavor.stringFlavor)}

// @ExecutionModes({ON_SELECTED_NODE})
String cc = getClipboardContents().toLowerCase();
String ec = node.style.getEdge().getColorCode();
String bc = node.style.backgroundColorCode;

if (!node.style.isBackgroundColorSet()) {
  bc = "#ffffff";
}

if ((cc == bc) && (cc != "#ffffff")) {
  node.style.getEdge().setColorCode(cc);
} else {
  node.style.backgroundColorCode = cc;
}
