<map version="freeplane 1.6.0">
<!--To view this file, download free mind mapping software Freeplane from http://freeplane.sourceforge.net -->
<node TEXT="MindMap"  LOCALIZED_STYLE_REF="AutomaticLayout.level.root" FOLDED="false">
  <hook NAME="MapStyle" zoom="1.5">
    <properties fit_to_viewport="false" show_icon_for_attributes="true" show_note_icons="true" edgeColorConfiguration="#888888,#DAECF6,#CDEEE9,#D9EDDD,#E8EAD6,#F6E6DA,#FCE3E7,#F7E3F4,#E8E6F9,#E8E8E8,#BBDFF2,#AAE4DC,#BAE3C1,#D7DBB3,#F2D3BA,#FBCBD3,#F3CEED,#D8D3F8,#D9D9D9"/>
    <map_styles>
      <stylenode LOCALIZED_TEXT="styles.root_node" STYLE="rectangle" UNIFORM_SHAPE="false" VGAP_QUANTITY="20.0 pt" TEXT_SHORTENED="true" MIN_WIDTH="120.0 pt" MAX_WIDTH="120.0 pt">
        <font SIZE="20" BOLD="true"/>
        <stylenode LOCALIZED_TEXT="styles.predefined" POSITION="right" STYLE="bubble">
          <font SIZE="9"/>
          <stylenode LOCALIZED_TEXT="default" COLOR="#202020" STYLE="bubble" TEXT_ALIGN="LEFT" SHAPE_VERTICAL_MARGIN="2.0 pt" BORDER_WIDTH="2.0 px">
            <font NAME="Calibri" SIZE="8" BOLD="false" ITALIC="false"/>
            <edge STYLE="bezier" WIDTH="2"/>
          </stylenode>
          <stylenode LOCALIZED_TEXT="defaultstyle.details">
            <font SIZE="11"/>
          </stylenode>
          <stylenode LOCALIZED_TEXT="defaultstyle.attributes" BACKGROUND_COLOR="#CCCCCC" VGAP_QUANTITY="5.0 pt">
            <font SIZE="9"/>
          </stylenode>
          <stylenode LOCALIZED_TEXT="defaultstyle.note" COLOR="#767EEA" BACKGROUND_COLOR="#FFFFFF"/>
          <stylenode LOCALIZED_TEXT="defaultstyle.floating">
            <edge STYLE="hide_edge"/>
          </stylenode>
        </stylenode>
        <stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="right" STYLE="bubble">
          <font SIZE="9"/>
          <stylenode LOCALIZED_TEXT="styles.important">
            <icon BUILTIN="yes"/>
            <edge COLOR="#0000cc"/>
          </stylenode>
        </stylenode>
        <stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="right" STYLE="bubble">
          <font SIZE="9"/>
          <stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" STYLE="bubble" BACKGROUND_COLOR="#CCCCCC" VGAP_QUANTITY="20.0 pt" BORDER_WIDTH="4.0 pt">
            <font SIZE="18" BOLD="true"/>
            <edge WIDTH="8" />
          </stylenode>
          <stylenode LOCALIZED_TEXT="AutomaticLayout.level,1" VGAP_QUANTITY="16.0 pt" BORDER_WIDTH="4.0 px" MIN_WIDTH="150.0 pt" MAX_WIDTH="150.0 pt">
            <font SIZE="16" BOLD="false"/>
            <edge WIDTH="6"/>
          </stylenode>
          <stylenode LOCALIZED_TEXT="AutomaticLayout.level,2" VGAP_QUANTITY="12.0 pt" BORDER_WIDTH="3.2 px" MIN_WIDTH="150.0 pt" MAX_WIDTH="150.0 pt">
            <font SIZE="14" BOLD="false"/>
            <edge WIDTH="4"/>
          </stylenode>
          <stylenode LOCALIZED_TEXT="AutomaticLayout.level,3" VGAP_QUANTITY="8.0 pt" BORDER_WIDTH="2.4 px" MIN_WIDTH="150.0 pt" MAX_WIDTH="150.0 pt">
            <font SIZE="12" BOLD="false"/>
          </stylenode>
          <stylenode LOCALIZED_TEXT="AutomaticLayout.level,4" VGAP_QUANTITY="4.0 pt">
            <font SIZE="12" BOLD="false"/>
          </stylenode>
          <stylenode LOCALIZED_TEXT="AutomaticLayout.level,5">
            <font SIZE="11" BOLD="false"/>
          </stylenode>
          <stylenode LOCALIZED_TEXT="AutomaticLayout.level,6">
            <font SIZE="10" BOLD="false"/>
          </stylenode>
        </stylenode>
      </stylenode>
    </map_styles>
  </hook>
  <hook NAME="AutomaticEdgeColor"  COUNTER="0" RULE="ON_BRANCH_CREATION"/>
  <edge COLOR="#CCCCCC"/>
</node>
</map>
